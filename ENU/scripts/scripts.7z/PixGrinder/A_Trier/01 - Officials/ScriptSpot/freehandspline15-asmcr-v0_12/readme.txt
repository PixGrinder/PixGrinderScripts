09.01.2k, swami*, a.k.a. "codeWarrior()", swami@cfl.rr.com


FreehandSpline15-AsMCR-v0_1.zip

"Bobo's 'freehandspline15.ms' as a MacroScript for MAX r3.x. Contains brief explanation of how to convert UtilityScript to MacroScript."
Here's the original description:
"FreehandSpline (FHS) lets you draw freeform splines with the mouse or tablet similar to drawing with a pencil. 
It lets you quickly create complex shapes with control over form and quality."


Contents:

freehandspline15.ms: Original UtilityScript by Bobo
- Works in r2.5 and r3.x.

FreehandSpline15-AsMCR-v0_1.mcr: Converted to MacroScript by swami*
- Works in r3.x.
- Install it like any other MacroScript. You will find it under "Bobo_s Tools" as "FreehandSpline15_MCR"
 
MAXr3Script-FreehandSpline15.html: Help



* It's a very cool script!  Be sure to look at the Listener while running the script...

ENJOY!