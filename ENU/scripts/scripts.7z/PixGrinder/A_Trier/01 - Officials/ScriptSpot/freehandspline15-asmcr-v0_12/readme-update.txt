12.01.01, swami@cfl.rr.com

Updated to maxR4.x (should work in previous released,too).

INSTALLLATION:
- Put script in max's macroscripts directory.
- Run max.
- Create toolbar button, or assign macroscript according to MaxHelp file.